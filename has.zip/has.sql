-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2022 at 08:20 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `has`
--

-- --------------------------------------------------------

--
-- Table structure for table `halls`
--

CREATE TABLE `halls` (
  `sn` int(10) NOT NULL,
  `hall_name` text NOT NULL,
  `location` text NOT NULL,
  `chief_potter` text NOT NULL,
  `status` text NOT NULL,
  `no_of_rooms` int(10) NOT NULL,
  `offset` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `halls`
--

INSERT INTO `halls` (`sn`, `hall_name`, `location`, `chief_potter`, `status`, `no_of_rooms`, `offset`) VALUES
(1, 'Hall 3', 'Boys Hostel', 'Mr. Adebanjo', 'active', 20, 1),
(2, 'Hall 2', 'Female Hostel', 'Mrs. Adebisi', '', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `mat_no` varchar(15) NOT NULL,
  `name` text NOT NULL,
  `sex` text NOT NULL,
  `dept` text NOT NULL,
  `level` int(3) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `sponsor` text NOT NULL,
  `saddress` text NOT NULL,
  `sphone` varchar(15) NOT NULL,
  `hall` text NOT NULL,
  `room` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`mat_no`, `name`, `sex`, `dept`, `level`, `phone`, `email`, `sponsor`, `saddress`, `sphone`, `hall`, `room`) VALUES
('190303001', 'Adekoya Adebowale', 'male', 'Computer Maths', 100, '09056734522', 'adekoyadebo@gmail.com', 'Adekoya Peter', '3, Unity str, Onike, Lagos', '08167546345', '', 0),
('', 'Anyawu Vanessa', 'Female', 'Computer Maths', 100, '090567456522', 'anyawuvan@gmail.com', 'Anyawu Uche', '15, Femi str, Bariga, Lagos', '090567456522', 'Hall 3', 1),
('190303005', 'Anyawu Vanessa', 'Female', 'Computer Maths', 100, '090567456522', 'anyawuvan@gmail.com', 'Anyawu Uche', '15, Femi str, Bariga, Lagos', '090567456522', 'Hall 3', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `staff_id` varchar(15) NOT NULL,
  `name` text NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`staff_id`, `name`, `username`, `password`) VALUES
('001', 'Eunice Adelere', 'eunice01', 'c1f07af05648771e320fe6ab40a6bd16'),
('002', 'Akinyemi ', 'sam01', '310b2ae7426e72097d2f5ca3f11df184');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `halls`
--
ALTER TABLE `halls`
  ADD PRIMARY KEY (`sn`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `halls`
--
ALTER TABLE `halls`
  MODIFY `sn` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
